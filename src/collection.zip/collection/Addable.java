package collection;

public interface Addable {
    int add(String element);
}

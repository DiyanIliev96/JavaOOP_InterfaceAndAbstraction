package militaryElite;

public enum Corps {
    Marines(),
    Airforces(),
}

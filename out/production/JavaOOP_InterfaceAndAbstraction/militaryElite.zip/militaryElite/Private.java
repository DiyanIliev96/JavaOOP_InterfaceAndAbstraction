package militaryElite;

public interface Private {
    double getSalary();
}

package militaryElite;

public interface LieutenantGeneral {
    void addPrivate(Private priv);
}
